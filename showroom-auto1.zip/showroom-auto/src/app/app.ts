import { Component } from '@angular/core';
import { NgIf } from '@angular/common';
import { HeadBar } from './head-bar/head-bar';
import { SearchBar } from './search-bar/search-bar';
import { Auto } from './auto';

@Component({
  imports: [HeadBar, SearchBar, NgIf],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  // Liste des voitures (images dans public/photos)
  autoList: Auto[] = [
    { brand: 'BMW', model: 'X2', price: 150, power: 7, photo: 'photos/bmw-x2.svg', units: 8 },
    { brand: 'BMW', model: 'X3', price: 190, power: 8, photo: 'photos/bmw-x3.svg', units: 5 },
    { brand: 'Audi', model: 'A3', price: 163, power: 6, photo: 'photos/audi-a3.svg', units: 11 },
    { brand: 'Audi', model: 'A4', price: 185, power: 7, photo: 'photos/audi-a4.svg', units: 6 },
    { brand: 'Peugeot', model: '208', price: 62, power: 4, photo: 'photos/peugeot-208.svg', units: 14 },
    { brand: 'Peugeot', model: '3008', price: 118, power: 6, photo: 'photos/peugeot-3008.svg', units: 9 },
    { brand: 'Renault', model: 'Clio', price: 55, power: 4, photo: 'photos/renault-clio.svg', units: 20 },
    { brand: 'Renault', model: 'Megane', price: 85, power: 5, photo: 'photos/renault-megane.svg', units: 12 },
  ];

  // Voiture sélectionnée (affichée en détail)
  selectedAuto?: Auto;

  // Appelée à la réception de l'évènement selectAutoEvent du composant fils
  updateAuto(auto: Auto): void {
    this.selectedAuto = auto;
  }
}
