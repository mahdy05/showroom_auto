import { Component, EventEmitter, Input, Output } from '@angular/core';
import { NgFor } from '@angular/common';
import { Auto } from '../auto';

@Component({
  imports: [NgFor],
  selector: 'app-search-bar',
  styleUrl: './search-bar.css',
  templateUrl: './search-bar.html',
})
export class SearchBar {
  // Communication parent -> fils : liste complète des voitures
  @Input() autos: Auto[] = [];

  // Communication fils -> parent : voiture sélectionnée
  @Output() selectAutoEvent = new EventEmitter<Auto>();

  // Résultat de la recherche
  searchResult: Auto[] = [];

  // Déclenchée par le clic sur le bouton Search
  searchAutoList(brand: string): void {
    const term = brand.trim().toLowerCase();
    this.searchResult = term
      ? this.autos.filter((a) => a.brand.toLowerCase() === term)
      : [];
  }

  // Émet la voiture sélectionnée vers le composant parent
  selectedAuto(auto: Auto): void {
    this.selectAutoEvent.emit(auto);
  }
}
